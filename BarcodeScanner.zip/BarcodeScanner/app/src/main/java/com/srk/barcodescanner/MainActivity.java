package com.srk.barcodescanner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void searchUser(View view){
        EditText et=findViewById(R.id.uniqueId);
        String uniqueId=et.getText().toString();
        if(uniqueId!=null){
            Intent intent = new Intent(this,scanner.class);
            intent.putExtra("uniqueId",uniqueId);
            startActivity(intent);
        }
        else{
            Toast.makeText(this, "Please enter a User ID", Toast.LENGTH_SHORT).show();
        }
    }
}
