package com.srk.barcodescanner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class scanner extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner);
        Intent intent = getIntent();
        String uniqueId=intent.getStringExtra("uniqueId");
        TextView tv = findViewById(R.id.display);
        tv.setText(uniqueId);
    }
}
